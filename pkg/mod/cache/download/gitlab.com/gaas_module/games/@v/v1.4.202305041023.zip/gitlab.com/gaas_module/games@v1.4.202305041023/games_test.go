package games_test

// func Test_Test(t *testing.T) {
// 	t.Logf("%+v\n", "hello,world!")
// }

// func Benchmark_Benchmarkb(b *testing.B) {
// 	for i := 0; i < b.N; i++ {
// 	}
// }
