package games

// RTPs - RTP 結構
type RTPs string
