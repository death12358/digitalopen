// Package doc is a generated GoDoc package.
// Packet goscriptor implements a way to use redis script more easily
package goscriptor
