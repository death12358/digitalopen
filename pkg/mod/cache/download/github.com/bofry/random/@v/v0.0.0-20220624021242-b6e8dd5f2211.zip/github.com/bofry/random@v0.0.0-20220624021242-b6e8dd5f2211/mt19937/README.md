# mt19937

---

`random/mt19937` is  a pseudo-random number generator  based on [mt19937-64.c](http://www.math.sci.hiroshima-u.ac.jp/m-mat/MT/VERSIONS/C-LANG/mt19937-64.c) implemented by go. It was originally implemented in c by Makoto Matsumoto and Takuji Nishimura.
